let cart = [];
let allItems = [];

window.onload = function () {
  const hotel = localStorage.getItem("hotel");

  if (hotel) {
    document.getElementById("hotelName").innerText =
      "🍽️ Welcome to " + hotel;
  }

  fetch(`http://localhost:5000/food?hotel=${hotel}`)
    .then(res => res.json())
    .then(data => {
      allItems = data;
      displayMenu(data);
    });
};

// DISPLAY MENU
function displayMenu(items) {
  const menu = document.getElementById("menu");
  menu.innerHTML = "";

  items.forEach(item => {
    const card = document.createElement("div");
    card.className = "card";

    card.innerHTML = `
      <img src="${item.image}">
      <h4>${item.name}</h4>
      <p>${item.category}</p>
      <p>₹${item.price}</p>

      <button class="add-btn">Add</button>
      <button class="order-btn">Order</button>
    `;

    card.querySelector(".add-btn").onclick = () => addToCart(item);
    card.querySelector(".order-btn").onclick = () => orderNow(item);

    menu.appendChild(card);
  });
}

// CART
function addToCart(item) {
  cart.push(item);
  updateCart();
}

function updateCart() {
  const cartDiv = document.getElementById("cart");
  const totalDiv = document.getElementById("total");

  cartDiv.innerHTML = "";
  let total = 0;

  cart.forEach(item => {
    total += item.price;
    cartDiv.innerHTML += `<p>${item.name} - ₹${item.price}</p>`;
  });

  totalDiv.innerText = "Total: ₹" + total;
}

// ✅ ORDER WITH ITEM + HOTEL
function orderNow(item) {
  const hotel = localStorage.getItem("hotel");

  fetch("http://localhost:5000/order", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({
      total: item.price,
      item_name: item.name,
      hotel: hotel
    })
  })
  .then(() => alert("Order placed 🎉"));
}

// FEEDBACK
function submitFeedback() {
  const name = document.getElementById("fbName").value;
  const message = document.getElementById("fbMessage").value;

  fetch("http://localhost:5000/feedback", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({ name, message })
  })
  .then(() => alert("Feedback submitted 😊"));
}